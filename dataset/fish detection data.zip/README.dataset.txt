# Fish4Knowledge Dataset > 640x640_borders
https://universe.roboflow.com/g18l5754/fish4knowledge-dataset

Provided by a Roboflow user
License: CC BY 4.0

