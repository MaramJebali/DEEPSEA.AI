# Fish Disease > 2023-10-04 9:03am
https://universe.roboflow.com/eki/fish-disease-t6b03

Provided by a Roboflow user
License: Public Domain

